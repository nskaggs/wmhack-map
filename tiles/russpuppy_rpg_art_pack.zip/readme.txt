Assets created by Russpuppy (http://russpuppy.com).  No attribution required but if you would like to you can attribute "Russpuppy (russpuppy.com)"

This art was used in the game Bear ABC Quest: https://play.google.com/store/apps/details?id=com.russpuppy.forestlegend
https://itunes.apple.com/us/app/bear-abc-quest/id663944603
http://www.youtube.com/watch?v=d5x8YdnDoOk

Free to use under the CCO license (http://creativecommons.org/publicdomain/zero/1.0/)